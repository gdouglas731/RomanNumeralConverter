﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RomanNumeralConverter
{
    class Program
    {
        static void Main(string[] args)
        {
            var romanNumeralConverter = new RomanNumeralConverter();
            var decimalConverter = new DecimalConverter();
            var input = string.Empty;

            do
            {
                Console.WriteLine("Enter the number you'd like to convert to roman numerals:");
                input = Console.ReadLine();

                if (input != string.Empty)
                {
                    var romanNumeral = romanNumeralConverter.ConvertToRomanNumerals(Convert.ToInt32(input));
                    Console.WriteLine(romanNumeral);
                    Console.WriteLine(decimalConverter.ConvertToDecimal(romanNumeral));
                }
            } while (input != string.Empty);
            
        }
    }
}