﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RomanNumeralConverter
{
    public class DecimalConverter
    {
        #region Roman Numeral > Decimal
        /// <summary>
        /// Does what it says on the tin
        /// </summary>
        /// <param name="romanNumerals"></param>
        /// <returns></returns>
        public int ConvertToDecimal(string romanNumerals)
        {
            List<RomanNumeralFragment> fragments = new List<RomanNumeralFragment>();
            // Remove fragments from string until the string is empty
            do
            {
                var fragment = GetFirstFragment(romanNumerals);
                fragments.Add(fragment);
                romanNumerals = romanNumerals.Remove(romanNumerals.IndexOf(fragment.RomanNumerals), fragment.RomanNumerals.Length);

            } while (romanNumerals != string.Empty);

            // Return the value of the combined fragments
            return fragments.Sum(f => f.Value);
        }

        /// <summary>
        /// Returns the integer value of the specified char in the RomanNumeral enum
        /// eg. X will return 10, M = 1000, etc
        /// </summary>
        /// <param name="romanNumeral"></param>
        /// <returns></returns>
        private int GetRomanNumeralValue(char romanNumeral)
        {
            RomanNumeral result;

            if (Enum.TryParse<RomanNumeral>(romanNumeral.ToString(), out result))
            {
                return (int)result;
            }

            return 0;
        }

        /// <summary>
        /// Returns the first RomanNumeralFragment from the specified string
        /// eg. CMIX would return CM, MMMCCCIX would return MMMCCC, etc.
        /// </summary>
        /// <param name="romanNumerals"></param>
        /// <returns></returns>
        private RomanNumeralFragment GetFirstFragment(string romanNumerals)
        {
            var letters = string.Empty;
            if (romanNumerals.Length > 1)
            {
                var firstChar = romanNumerals[0];
                var secondChar = romanNumerals[1];

                // if subtractive, it will only use first 2 chars if the first is less than the second
                if (GetRomanNumeralValue(firstChar) < GetRomanNumeralValue(secondChar))
                {
                    return new RomanNumeralFragment
                    {
                        RomanNumerals = firstChar.ToString() + secondChar.ToString()
                    };
                }
                else
                {
                    // additive - loop through letters until end or we come across a subtractive fragment
                    for (int i = 0; i < romanNumerals.Length; i++)
                    {
                        var letter = romanNumerals[i];

                        // add letter to string
                        if (letters == string.Empty)
                        {
                            letters += letter;
                        }
                        else
                        {
                            // if last letter, append to string
                            if (i == romanNumerals.Length - 1)
                            {
                                letters += letter;
                            }
                            else
                            {
                                //check if current and subsequent letter are subtractive
                                var secondLetter = romanNumerals[i + 1];

                                if (GetRomanNumeralValue(letter) < GetRomanNumeralValue(secondLetter))
                                {
                                    // if subtractive, return fragment without current letter
                                    return new RomanNumeralFragment
                                    {
                                        RomanNumerals = letters
                                    };
                                }
                                else
                                {
                                    // add letter to string
                                    letters += letter;
                                }
                            }
                        }
                    }

                    return new RomanNumeralFragment
                    {
                        RomanNumerals = letters
                    };
                }
            }
            else
            {
                // return single letter fragment
                return new RomanNumeralFragment
                {
                    RomanNumerals = romanNumerals
                };
            }
        }

        #endregion
    }
}