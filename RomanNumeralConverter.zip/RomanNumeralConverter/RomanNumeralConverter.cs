﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RomanNumeralConverter
{
    public class RomanNumeralConverter
    {
        #region Decimal > Roman Numeral
        /// <summary>
        /// Does what it says on the tin
        /// </summary>
        /// <param name="number"></param>
        /// <returns></returns>
        public string ConvertToRomanNumerals(int number)
        {
            // Create fragment list and list of numeral characters to loop through
            List<RomanNumeralFragment> result = new List<RomanNumeralFragment>();
            List<RomanNumeral> romanNumerals = new List<RomanNumeral>();

            romanNumerals.Add(RomanNumeral.M);
            romanNumerals.Add(RomanNumeral.D);
            romanNumerals.Add(RomanNumeral.C);
            romanNumerals.Add(RomanNumeral.L);
            romanNumerals.Add(RomanNumeral.X);
            romanNumerals.Add(RomanNumeral.V);
            romanNumerals.Add(RomanNumeral.I);

            foreach (var romanNumeral in romanNumerals)
            {
                var fragments = ProcessRomanNumeral(romanNumeral, number);

                // Deduct value of fragment from remaining number
                number = number - fragments.Sum(f => f.Value);

                result.AddRange(fragments);
            }

            // Join fragment strings together and output
            var output = String.Join("", result.Select(r => r.RomanNumerals).AsEnumerable());
            return output;
        }

        /// <summary>
        /// Returns one of:
        ///     0 fragments
        ///     1 additive or subtractive fragment
        ///     Both
        /// </summary>
        /// <param name="romanNumeral"></param>
        /// <param name="value"></param>
        /// <returns></returns>
        private List<RomanNumeralFragment> ProcessRomanNumeral(RomanNumeral romanNumeral, int value)
        {
            var result = new List<RomanNumeralFragment>();
            var count = GetFullNumeralCount(value, romanNumeral);

            var fragmentString = AppendAdditiveFragmentString(count, romanNumeral);

            if (fragmentString != string.Empty)
            {
                var fragment = new RomanNumeralFragment
                {
                    RomanNumerals = fragmentString,
                };

                result.Add(fragment);

                value = value - fragment.Value;
            }

            var subtractiveFragment = GetSubtractiveFragment(romanNumeral, value);

            if (subtractiveFragment != null)
            {
                result.Add(subtractiveFragment);
            }

            return result;
        }

        /// <summary>
        /// Returns a subtractive fragment using the specified roman numeral.  Returns null if not needed
        /// </summary>
        /// <param name="currentRomanNumeral"></param>
        /// <param name="value"></param>
        /// <returns></returns>
        private RomanNumeralFragment GetSubtractiveFragment(RomanNumeral currentRomanNumeral, int value)
        {
            RomanNumeralFragment fragment = null;

            // check if value if difference is greater than numeral minus C
            if ((value > (int)RomanNumeral.C) && (value >= ((int)currentRomanNumeral - (int)RomanNumeral.C)))
            {
                // if greater, we need to use a C subtractive fragment
                fragment = new RomanNumeralFragment
                {
                    RomanNumerals = AppendSubtractiveFragmentString(RomanNumeral.C, currentRomanNumeral)
                };
            }
            // if false, check for X and I using rules above
            else if ((value > (int)RomanNumeral.X) && (value >= ((int)currentRomanNumeral - (int)RomanNumeral.X)))
            {
                // if greater, we need to use a X subtractive fragment
                fragment = new RomanNumeralFragment
                {
                    RomanNumerals = AppendSubtractiveFragmentString(RomanNumeral.X, currentRomanNumeral)
                };
            }
            else if ((value > (int)RomanNumeral.I) && (value >= ((int)currentRomanNumeral - (int)RomanNumeral.I)))
            {
                // if greater, we need to use a I subtractive fragment
                fragment = new RomanNumeralFragment
                {
                    RomanNumerals = AppendSubtractiveFragmentString(RomanNumeral.I, currentRomanNumeral)
                };
            }

            return fragment;
        }

        /// <summary>
        /// Returns a string representation of the specified numeral and numeral count
        /// </summary>
        /// <param name="numeralCount"></param>
        /// <param name="romanNumeral"></param>
        /// <returns></returns>
        private string AppendAdditiveFragmentString(int numeralCount, RomanNumeral romanNumeral)
        {
            string result = string.Empty;

            for (int i = 0; i < numeralCount; i++)
            {
                result += romanNumeral.ToString();
            }

            return result;
        }

        /// <summary>
        /// Simply appends first and second parameters as a concatenated string
        /// </summary>
        /// <param name="firstLetter"></param>
        /// <param name="secondLetter"></param>
        /// <returns></returns>
        private string AppendSubtractiveFragmentString(RomanNumeral firstLetter, RomanNumeral secondLetter)
        {
            var result = firstLetter.ToString() + secondLetter.ToString();
            return result;
        }

        ///// <summary>
        ///// Returns the number of numerals required for the specified value.  Does not include subtractive fragments
        ///// </summary>
        ///// <param name="value"></param>
        ///// <param name="numeral"></param>
        ///// <returns></returns>
        private int GetFullNumeralCount(int value, RomanNumeral numeral)
        {
            // Get number of whole numerals to return from value
            int numeralCount = value / (int)numeral;

            return numeralCount;
        }
        #endregion
    }
}