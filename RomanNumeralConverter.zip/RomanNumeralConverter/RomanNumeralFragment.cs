﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RomanNumeralConverter
{
    public class RomanNumeralFragment
    {
        public string RomanNumerals { get; set; }
        public int Value { 
            get            
            {
                var result = 0;

                if (IsAdditive)
	            {
		            foreach (var chr in RomanNumerals)
                    {
                        result += GetRomanNumeralValue(chr);
                    } 
	            }
                else if(IsSubtractive)
                {
                    result = GetRomanNumeralValue(RomanNumerals[1]) - GetRomanNumeralValue(RomanNumerals[0]);
                }
                else
                {
                    result = GetRomanNumeralValue(RomanNumerals[0]);
                }

                return result;
            }
        }

        public bool IsAdditive
        {
            get
            {
                // if only one character long, return false
                if (this.RomanNumerals.Length <= 1)
                    return false;

                // if first letter is less than second letter, return false
                RomanNumeral firstLetter;
                Enum.TryParse<RomanNumeral>(RomanNumerals[0].ToString(), out firstLetter);

                RomanNumeral secondLetter;
                Enum.TryParse<RomanNumeral>(RomanNumerals[1].ToString(), out secondLetter);

                return (int)firstLetter >= (int)secondLetter;
            }
        }

        public bool IsSubtractive { 
            get
            {
                // if only one character long, return false
                if (this.RomanNumerals.Length <= 1)
                    return false;

                // if first letter is less than second letter, return true
                RomanNumeral firstLetter;
                Enum.TryParse<RomanNumeral>(RomanNumerals[0].ToString(), out firstLetter);

                RomanNumeral secondLetter;
                Enum.TryParse<RomanNumeral>(RomanNumerals[1].ToString(), out secondLetter);

                return (int)firstLetter < (int)secondLetter;
            }
        }

        private int GetRomanNumeralValue(char romanNumeral)
        {
            RomanNumeral result;

            if (Enum.TryParse<RomanNumeral>(romanNumeral.ToString(), out result))
            {
                return (int)result;
            }

            //should probably throw exception
            return 0;
        }
    }
}
